"use client";
import axios, { AxiosError } from "axios";
import { useRouter } from "next/navigation";
import { useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";

type SignInResponse = {
  ok: boolean;
  message?: string;
};

export default function CmuEntraIDCallback() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const code = searchParams.get("code");
  const [message, setMessage] = useState("");

  useEffect(() => {
    // Wait for code to be ready
    if (!code) return;

    axios
      .post<SignInResponse>("/api/entraid/signin", { authorizationCode: code })
      .then((resp) => {
        if (resp.data.ok) {
          // Redirect to appropriate dashboard
          // For now, redirect to home and let middleware handle routing
          router.push("/");
        }
      })
      .catch((error: AxiosError<SignInResponse>) => {
        if (!error.response) {
          setMessage(
            "Cannot connect to server. Please try again later."
          );
        } else if (error.response.data && !error.response.data.ok) {
          setMessage(error.response.data.message || "Login failed");
        } else {
          setMessage("Unknown error occurred. Please try again later.");
        }
      });
  }, [code, router]);

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900 text-white">
      <div className="text-center">
        {message ? (
          <div>
            <h1 className="text-2xl font-bold mb-4">❌ Login Failed</h1>
            <p className="text-red-400">{message}</p>
            <button
              onClick={() => router.push("/")}
              className="mt-4 px-4 py-2 bg-blue-600 rounded hover:bg-blue-700"
            >
              Back to Home
            </button>
          </div>
        ) : (
          <div>
            <h1 className="text-2xl font-bold mb-4">🔄 Signing in...</h1>
            <p className="text-gray-400">Please wait while we log you in.</p>
          </div>
        )}
      </div>
    </div>
  );
}
