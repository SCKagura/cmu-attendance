-- AlterTable
ALTER TABLE "TokenLog" ADD COLUMN "device" TEXT;

-- AlterTable
ALTER TABLE "User" ADD COLUMN "itaccounttype_id" TEXT;
